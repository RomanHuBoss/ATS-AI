"""
Domain models and value objects.

Contains fundamental domain entities like RiskUnits, Position, Trade, etc.
"""
