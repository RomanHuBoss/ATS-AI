"""
Unit tests for ATS-AI modules

Each test module corresponds to a source module and tests its invariants,
edge cases, and compliance with ТЗ requirements.
"""
