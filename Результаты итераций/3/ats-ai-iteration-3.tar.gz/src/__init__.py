"""
ATS-AI v3.30 — Algorithmic Trading System for Crypto Markets

Core package root.
"""

__version__ = "0.1.0"
